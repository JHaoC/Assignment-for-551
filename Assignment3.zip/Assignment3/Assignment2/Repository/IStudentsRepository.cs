﻿using Assignment1.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Assignment1.Repository
{
    public interface IStudentsRepository
    {
        Task<Student> Delete(int id);
        Task<Student> EditAsync(Student student);
        Task<Student> GetAsync(int id);
        Task<List<Student>> ListAsync();
        Task<int> postAsync(Student student);
    }
}