﻿using Assignment1.Data;
using Assignment1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment1.Repository
{
    public class StudentsRepository : IStudentsRepository
    {
        private readonly AppDbContext _dbContext;

        public StudentsRepository(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<Student>> ListAsync()
        {
            return await _dbContext.Students.ToListAsync();
        }

        public async Task<Student> GetAsync(int id)
        {
            return await _dbContext.Students.FindAsync(id);
        }

        public async Task<int> postAsync(Student student)
        {
            _dbContext.Students.Add(student);
            await _dbContext.SaveChangesAsync();
            return student.ID;
        }


        public async Task<Student> EditAsync(Student student)
        {
            _dbContext.Students.Update(student);
            await _dbContext.SaveChangesAsync();
            return student;
        }

        public async Task<Student> Delete(int id)
        {
            var student = await _dbContext.Students.FindAsync(id);
            _dbContext.Students.Remove(student);
            await _dbContext.SaveChangesAsync();
            return student;
        }
    }
}

